# -*- coding: utf-8 -*-

from . import contact_fields, company_fields, deal_fields, \
    mail_activity_fields, ticket_fields, models, companyone2manymodels, dealone2manymodels, \
    ticketone2manymodels, contactone2manymodels
